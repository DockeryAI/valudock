# Cloud Function Verification - Visual Walkthrough

## 🎬 Step-by-Step Visual Guide

---

## Scenario 1: First-Time Verification (All Secrets Configured)

### Step 1: Navigate to Cloud Run Console

```
┌──────────────────────────────────────────────────────────────┐
│ Admin Dashboard                                              │
├──────────────────────────────────────────────────────────────┤
│ [Users] [Groups] [Webhooks] [Proposal Agent] [Secrets] ... │
│                              ▲                                │
│                              └─ Click here                    │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 2: Enable Cloud Run

```
┌──────────────────────────────────────────────────────────────┐
│ Agent Configuration                                          │
├──────────────────────────────────────────────────────────────┤
│ Run in Cloud                            [✓ ON]               │
│                                         ▲                     │
│                                         └─ Toggle ON          │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 3: Expand Cloud Run Console

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌄   │ ← Click header
│ Deploy and test the Edge Function                           │
└──────────────────────────────────────────────────────────────┘

                        ↓ Expands to ↓

┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────┐  ┌─────────────────────────┐   │
│ │ ✓ Verify Cloud Function │  │ 🔧 Deploy Edge Function │   │
│ └─────────────────────────┘  └─────────────────────────┘   │
│             ▲                                                │
│             └─ Click this button                             │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 4: Click "Verify Cloud Function"

**Before Click:**
```
┌─────────────────────────┐
│ ✓ Verify Cloud Function │
└─────────────────────────┘
```

**During Verification (2 seconds):**
```
┌─────────────────────────┐
│ ⟳ Verifying...          │
└─────────────────────────┘
```

---

### Step 5: View Results - SUCCESS! ✅

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────┐  ┌─────────────────────────┐   │
│ │ ✓ Verify Cloud Function │  │ 🔧 Deploy Edge Function │   │
│ └─────────────────────────┘  └─────────────────────────┘   │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ✅ Edge Function: Connected    [Connected ✓]          │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ Secrets Loaded                                               │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ OpenAI                                             ✅  │  │
│ │ Supabase URL (ValueDock)                           ✅  │  │
│ │ Supabase Service Role (ValueDock)                  ✅  │  │
│ │ Gamma                                              ✅  │  │
│ │ Fathom                                             ✅  │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ 🔍 Verifying cloud function...                              │
│ 📤 Sending verification request...                          │
│ {                                                            │
│   "tenant_id": "uuid-123",                                  │
│   "org_id": "uuid-456",                                     │
│   "deal_id": "TEST-VERIFY-1729123456789",                  │
│   ...                                                        │
│ }                                                            │
│                                                              │
│ 📥 Response received:                                        │
│ {                                                            │
│   "status": "verified",                                     │
│   "message": "✅ All secrets loaded successfully",          │
│   "allSecretsLoaded": true,                                 │
│   ...                                                        │
│ }                                                            │
│                                                              │
│ ✅ Edge Function is Connected                               │
│                                                              │
│ 📋 Secrets Status:                                          │
│   OpenAI: ✅                                                │
│   Supabase URL (ValueDock): ✅                              │
│   Supabase Service Role (ValueDock): ✅                     │
│   Gamma: ✅                                                 │
│   Fathom: ✅                                                │
└──────────────────────────────────────────────────────────────┘

         ↓ Toast notification appears ↓

┌──────────────────────────────────────────────────────────────┐
│ ✅ Edge Function connected - all secrets loaded!             │
└──────────────────────────────────────────────────────────────┘
```

---

## Scenario 2: Missing Secrets (Gamma & Fathom)

### Step 5: View Results - PARTIAL ⚠️

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────┐  ┌─────────────────────────┐   │
│ │ ✓ Verify Cloud Function │  │ 🔧 Deploy Edge Function │   │
│ └─────────────────────────┘  └─────────────────────────┘   │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ✅ Edge Function: Connected    [Connected ✓]          │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ Secrets Loaded                      [⚠ Fix in Admin]        │
│                                             ▲                │
│                                             └─ Click to fix  │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ OpenAI                                             ✅  │  │
│ │ Supabase URL (ValueDock)                           ✅  │  │
│ │ Supabase Service Role (ValueDock)                  ✅  │  │
│ │ Gamma                                              ❌  │  │
│ │ Fathom                                             ❌  │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ⚠️ Some secrets are missing    [Missing Secrets]      │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ 🔍 Verifying cloud function...                              │
│ ...                                                          │
│ 📋 Secrets Status:                                          │
│   OpenAI: ✅                                                │
│   Supabase URL (ValueDock): ✅                              │
│   Supabase Service Role (ValueDock): ✅                     │
│   Gamma: ❌                                                 │
│   Fathom: ❌                                                │
└──────────────────────────────────────────────────────────────┘

         ↓ Toast notification appears ↓

┌──────────────────────────────────────────────────────────────┐
│ ⚠️ Edge Function connected but some secrets are missing      │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 6: Click "Fix in Admin"

```
┌────────────────────────────────────────────────────────────┐
│ Secrets Loaded                      [⚠ Fix in Admin]      │
│                                             ▲              │
│                                             └─ Click       │
└────────────────────────────────────────────────────────────┘

                        ↓ Shows toast ↓

┌──────────────────────────────────────────────────────────────┐
│ ℹ️ Navigate to Admin → Secrets to configure missing secrets │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 7: Navigate to Admin → Secrets

```
┌──────────────────────────────────────────────────────────────┐
│ Admin Dashboard                                              │
├──────────────────────────────────────────────────────────────┤
│ [Users] [Groups] [Webhooks] [Proposal Agent] [Secrets] ...  │
│                                               ▲              │
│                                               └─ Click here  │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 8: Add Missing Secrets

```
┌──────────────────────────────────────────────────────────────┐
│ Secrets Management                                           │
├──────────────────────────────────────────────────────────────┤
│ OpenAI API Key                    [Configured ✓]            │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ sk-proj-...                                            │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ Gamma API Key                     [Not Configured ✗]        │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ [Enter Gamma API key here]                             │  │ ← Add key
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ Fathom API Key                    [Not Configured ✗]        │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ [Enter Fathom API key here]                            │  │ ← Add key
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│                                        [Save Secrets]        │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 9: Return to Proposal Agent and Verify Again

```
Back to: Admin → Proposal Agent → Cloud Run Console

Click: "Verify Cloud Function"

Result: All checkmarks now ✅ green!

┌────────────────────────────────────────────────────────────┐
│ Secrets Loaded                                             │
│ ┌──────────────────────────────────────────────────────┐  │
│ │ OpenAI                                           ✅  │  │
│ │ Supabase URL (ValueDock)                         ✅  │  │
│ │ Supabase Service Role (ValueDock)                ✅  │  │
│ │ Gamma                                            ✅  │  │ ← Fixed!
│ │ Fathom                                           ✅  │  │ ← Fixed!
│ └──────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────┘
```

---

## Scenario 3: Edge Function Not Deployed

### Step 5: View Results - ERROR ❌

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────┐  ┌─────────────────────────┐   │
│ │ ✓ Verify Cloud Function │  │ 🔧 Deploy Edge Function │   │
│ └─────────────────────────┘  └─────────────────────────┘   │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ❌ Edge Function: Not Connected  [Not Connected]      │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ 🔍 Verifying cloud function...                              │
│ 📤 Sending verification request...                          │
│                                                              │
│ ❌ Error: Failed to fetch                                   │
│ Network request failed - edge function may not be deployed  │
└──────────────────────────────────────────────────────────────┘

         ↓ Toast notification appears ↓

┌──────────────────────────────────────────────────────────────┐
│ ❌ Verification error: Failed to fetch                       │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 6: Deploy Edge Function First

```
┌──────────────────────────────────────────────────────────────┐
│ ┌─────────────────────────┐  ┌─────────────────────────┐   │
│ │ ✓ Verify Cloud Function │  │ 🔧 Deploy Edge Function │   │
│ └─────────────────────────┘  └─────────────────────────┘   │
│                                         ▲                    │
│                                         └─ Click this first  │
└──────────────────────────────────────────────────────────────┘

                        ↓ After deployment ↓

┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console  [Deployment Verified ✓]          ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ...deployment log...                                         │
│ ✅ Deployment verified - endpoint returning {status:...}    │
└──────────────────────────────────────────────────────────────┘

              ↓ Now verify again ↓

Click "Verify Cloud Function" → Should work now!
```

---

## 🎯 Key Visual Elements

### Status Colors

```
🟢 Green = Good
   ├─ Connected badge
   ├─ Checkmarks for loaded secrets
   └─ Success alerts

🔴 Red = Problem
   ├─ Not Connected badge
   ├─ X marks for missing secrets
   └─ Error alerts

🟡 Yellow = Warning
   ├─ Missing Secrets badge
   └─ Partial success alerts

⚫ Gray = Neutral
   ├─ Deploying status
   └─ Testing status
```

### Icons

```
✅ CheckCircle2  = Success
❌ XCircle       = Error
⚠️ AlertCircle   = Warning
🔧 Wrench        = Console/Tools
🔍 Search        = Verification
📤 Send          = Request
📥 Receive       = Response
📋 Clipboard     = Checklist
```

### Badges

```
[Connected ✓]           Green background
[Not Connected]         Red background
[Missing Secrets]       Yellow outline
[Deployment Verified ✓] Green background
```

---

## 💡 Visual Patterns to Remember

### 1. Two-Button Layout
```
[Verify] [Deploy]
  ↑         ↑
  Test     Setup
```

### 2. Traffic Light System
```
Green Alert  = All good
Yellow Alert = Action needed
Red Alert    = Problem
```

### 3. Checklist Pattern
```
Item ✅  = Configured
Item ❌  = Missing
```

### 4. Expandable Console
```
Header ⌄  = Collapsed
Header ⌃  = Expanded
```

---

**Navigation Flow:**
```
Admin → Proposal Agent → Cloud Run Console → Verify → Fix (if needed) → Verify Again
```

**Success Path:**
```
Toggle ON → Expand Console → Verify → ✅ All Green → Done!
```

**Fix Path:**
```
Verify → ⚠️ Yellow Badge → Fix in Admin → Secrets Tab → Add Keys → Save → Verify → ✅ All Green
```

---

**Last Updated:** 2025-10-16  
**Full Guide:** `CLOUD_FUNCTION_VERIFICATION_GUIDE.md`  
**Quick Ref:** `CLOUD_VERIFICATION_QUICK_REF.md`
