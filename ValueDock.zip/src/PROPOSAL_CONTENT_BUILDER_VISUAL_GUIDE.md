# Proposal Content Builder - Visual Guide

## 🎨 Complete UI Walkthrough

This guide shows exactly what users will see and interact with when using the Proposal Content Builder.

---

## 📱 Main Interface

### **Top-Level Tabs**

```
┌──────────────────────────────────────────────────────────┐
│                     Proposal Builder                      │
├──────────────────────────────────────────────────────────┤
│ 🏢 Acme Corp → West Division → DEAL-2025-001             │
│                                                           │
│ Proposal Builder           📄 Version 2 [Draft]          │
│ Generate AI proposals      [▼ Switch] [+ New]           │
├──────────────────────────────────────────────────────────┤
│ ┌──────────────────────────────────────────────────────┐│
│ │ [ Agent Runner ] [ Content Builder ]                 ││
│ └──────────────────────────────────────────────────────┘│
│                                                           │
│ (Content displays based on active tab)                   │
└──────────────────────────────────────────────────────────┘
```

---

## 🚀 Agent Runner Tab (Existing)

```
┌──────────────────────────────────────────────────────────┐
│ [ Agent Runner ] Content Builder                         │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ ℹ️ Proposal Agent: Automatically generates proposals...  │
│                                                           │
│ ┌─────────────────────┬───────────────────────────────┐ │
│ │ Configuration       │ Agent Status Log              │ │
│ │                     │                               │ │
│ │ Deal ID:            │ Ready to generate proposal    │ │
│ │ [DEAL-2025-001]    │                               │ │
│ │                     │                               │ │
│ │ Customer URL:       │                               │ │
│ │ [https://acme.com] │                               │ │
│ │                     │                               │ │
│ │ [  Run Agent  ]     │                               │ │
│ │ [Run & Save Version]│                               │ │
│ └─────────────────────┴───────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

---

## 📝 Content Builder Tab (NEW)

### **Initial View - Section Tabs**

```
┌──────────────────────────────────────────────────────────┐
│ Agent Runner [ Content Builder ]                         │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ Proposal Content Builder        [💾 Save All Sections]   │
│ Edit sections and export to Gamma                        │
│                                                           │
│ ┌────────────────────────────────────────────────────┐  │
│ │ Proposal Sections                                   │  │
│ │ Edit each section below. AI-generated content...    │  │
│ ├────────────────────────────────────────────────────┤  │
│ │ ┌───────────────────────────────────────────────┐  │  │
│ │ │ [📄 Overview] [🎯 Challenges✓] [💰 ROI]...   │  │  │
│ │ └───────────────────────────────────────────────┘  │  │
│ │                                                     │  │
│ │ (Section content displays here)                    │  │
│ └────────────────────────────────────────────────────┘  │
│                                                           │
│ ┌────────────────────────────────────────────────────┐  │
│ │ Export to Gamma                                     │  │
│ │ Generate professional documents and presentations   │  │
│ ├────────────────────────────────────────────────────┤  │
│ │ [Gamma Doc]           [Gamma Deck]                 │  │
│ └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

---

## 🎯 Section Editing Interface

### **Overview Section**

```
┌──────────────────────────────────────────────────────────┐
│ [📄 Overview] 🎯 Challenges  💰 ROI  💡 Solution  ✅ SOW │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ 📄 Overview                               [Reset]        │
│ Executive summary and company background                 │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ ℹ️ AI Prompt:                                       │ │
│ │ Generate an executive overview section for a        │ │
│ │ ValueDock proposal. Include: 1) Brief company...    │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ # Company Overview                                  │ │
│ │                                                     │ │
│ │ [Company Name] is seeking to transform their       │ │
│ │ operations through intelligent automation. This    │ │
│ │ proposal outlines a comprehensive solution to      │ │
│ │ address their key challenges and achieve           │ │
│ │ measurable ROI.                                     │ │
│ │                                                     │ │
│ │ ## Current Situation                                │ │
│ │ - Manual processes creating operational            │ │
│ │   bottlenecks                                       │ │
│ │ - Limited visibility into process efficiency       │ │
│ │ - Opportunities for significant cost reduction     │ │
│ │                                                     │ │
│ │ ## Our Approach                                     │ │
│ │ DockeryAI provides end-to-end workflow             │ │
│ │ automation tailored to your specific needs.        │ │
│ │                                                     │ │
│ └─────────────────────────────────────────────────────┘ │
│ 542 characters                                            │
└──────────────────────────────────────────────────────────┘
```

### **Challenges & Goals Section (Edited)**

```
┌──────────────────────────────────────────────────────────┐
│ 📄 Overview  [🎯 Challenges✓] 💰 ROI  💡 Solution  ✅ SOW│
├──────────────────────────────────────────────────────────┤
│                                                           │
│ 🎯 Challenges & Goals                     [Reset]        │
│ Client pain points and objectives                        │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ ℹ️ AI Prompt:                                       │ │
│ │ Based on Fathom meeting transcripts and website...  │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ # Challenges & Goals                                │ │
│ │                                                     │ │
│ │ ## Key Challenges                                   │ │
│ │ 1. **Process Inefficiency**: Manual workflows      │ │
│ │    consuming excessive time and resources          │ │
│ │ 2. **Error Rates**: Human error in repetitive      │ │
│ │    tasks impacting quality                          │ │
│ │ 3. **Scalability**: Current operations cannot      │ │
│ │    support growth targets                           │ │
│ │                                                     │ │
│ │ ## Strategic Goals                                  │ │
│ │ 1. Reduce operational costs by 30%+                │ │
│ │ 2. Improve process accuracy to 99%+                │ │
│ │ 3. Enable team to focus on high-value activities   │ │
│ │                                                     │ │
│ └─────────────────────────────────────────────────────┘ │
│ 628 characters                          [✓ Edited]       │
└──────────────────────────────────────────────────────────┘
```

---

## 💰 Export Section

### **Before Export**

```
┌──────────────────────────────────────────────────────────┐
│ Export to Gamma                                          │
│ Generate professional documents and presentations        │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ ┌────────────────────────┬────────────────────────────┐ │
│ │ 📄 Gamma Document      │ ✅ Gamma Presentation      │ │
│ │ Comprehensive proposal │ Executive presentation     │ │
│ │ document               │ deck                       │ │
│ │                        │                            │ │
│ │ [Export to Gamma Doc]  │ [Export to Gamma Deck]     │ │
│ │                        │                            │ │
│ └────────────────────────┴────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

### **During Export (Loading)**

```
┌──────────────────────────────────────────────────────────┐
│ Export to Gamma                                          │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ ┌────────────────────────┬────────────────────────────┐ │
│ │ 📄 Gamma Document      │ ✅ Gamma Presentation      │ │
│ │                        │                            │ │
│ │ [⏳ Creating...]       │ [Export to Gamma Deck]     │ │
│ │  (Spinner animation)   │                            │ │
│ │                        │                            │ │
│ └────────────────────────┴────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

### **After Export (Success)**

```
┌──────────────────────────────────────────────────────────┐
│ Export to Gamma                                          │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ ┌────────────────────────┬────────────────────────────┐ │
│ │ 📄 Gamma Document      │ ✅ Gamma Presentation      │ │
│ │                        │                            │ │
│ │ [Export to Gamma Doc]  │ [Export to Gamma Deck]     │ │
│ │                        │                            │ │
│ │ ✅ Created  [Open]     │ ✅ Created  [Open]         │ │
│ │                        │                            │ │
│ └────────────────────────┴────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

### **After Export (Error)**

```
┌──────────────────────────────────────────────────────────┐
│ Export to Gamma                                          │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ ┌────────────────────────┬────────────────────────────┐ │
│ │ 📄 Gamma Document      │ ✅ Gamma Presentation      │ │
│ │                        │                            │ │
│ │ [Export to Gamma Doc]  │ [Export to Gamma Deck]     │ │
│ │                        │                            │ │
│ │ ❌ Failed              │                            │ │
│ │                        │                            │ │
│ └────────────────────────┴────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

---

## 🔄 Complete User Flow

### **Flow 1: First-Time User**

```
Step 1: Navigate to Proposal Builder
┌──────────────────────────────────┐
│ Admin → Agent → Proposal Builder │
└──────────────────────────────────┘
              ↓
Step 2: Agent Runner Tab
┌──────────────────────────────────┐
│ [ Agent Runner ] Content Builder │ ← Tab disabled
│                                  │
│ Deal ID: [DEAL-2025-001]        │
│ URL: [https://acme.com]         │
│                                  │
│ [Run & Save Version]             │
└──────────────────────────────────┘
              ↓
Step 3: Agent Running
┌──────────────────────────────────┐
│ [⏳ Running...]                  │
│                                  │
│ Agent Status Log:                │
│ 🌐 Website    [✅ Success]       │
│ 🎤 Fathom     [✅ Success]       │
│ 📄 ValueDock  [✅ Success]       │
│ 🎨 Gamma      [✅ Success]       │
└──────────────────────────────────┘
              ↓
Step 4: Version Created
┌──────────────────────────────────┐
│ [ Agent Runner ] Content Builder │ ← Tab enabled!
│                    ↑             │
│                    └─ Click here │
└──────────────────────────────────┘
              ↓
Step 5: Content Builder Tab
┌──────────────────────────────────┐
│ Agent Runner [ Content Builder ] │
│                                  │
│ [📄 Overview] 🎯 Challenges...  │
│                                  │
│ # Company Overview               │
│ [Company Name] is seeking...     │
│                                  │
│ [Save All Sections]              │
└──────────────────────────────────┘
              ↓
Step 6: Edit & Export
┌──────────────────────────────────┐
│ 1. Edit sections                 │
│ 2. Click "Save All Sections"     │
│ 3. Click "Export to Gamma Doc"   │
│ 4. Wait for "✅ Created"         │
│ 5. Click "Open"                  │
│ 6. Share link!                   │
└──────────────────────────────────┘
```

---

## 📊 State Indicators

### **Tab States**

```
┌────────────────────────────────────────┐
│ BEFORE VERSION CREATION:               │
│ [ Agent Runner ] Content Builder       │
│                  └─ Grayed out         │
└────────────────────────────────────────┘

┌────────────────────────────────────────┐
│ AFTER VERSION CREATION:                │
│ [ Agent Runner ] [ Content Builder ]   │
│                  └─ Active, clickable  │
└────────────────────────────────────────┘
```

### **Section Tab States**

```
┌────────────────────────────────────────┐
│ UNEDITED SECTION:                      │
│ [📄 Overview]                          │
│  └─ No badge                           │
└────────────────────────────────────────┘

┌────────────────────────────────────────┐
│ EDITED SECTION:                        │
│ [📄 Overview ✓]                        │
│  └─ Check badge (blue)                 │
└────────────────────────────────────────┘

┌────────────────────────────────────────┐
│ ACTIVE SECTION:                        │
│ [📄 Overview]                          │
│  └─ Blue underline/highlight           │
└────────────────────────────────────────┘
```

### **Export States**

```
IDLE (Not exported):
┌─────────────────────┐
│ [Export to Gamma]   │
└─────────────────────┘

LOADING:
┌─────────────────────┐
│ [⏳ Creating...]    │
│  (Spinner)          │
└─────────────────────┘

SUCCESS:
┌─────────────────────┐
│ ✅ Created  [Open]  │
└─────────────────────┘

ERROR:
┌─────────────────────┐
│ ❌ Failed           │
└─────────────────────┘
```

---

## 🎨 Color Coding

### **Status Colors**

```
✅ Success:
- Background: bg-green-50 (light) / bg-green-950 (dark)
- Border: border-green-200 / border-green-800
- Icon: text-green-600 / text-green-400
- Text: text-green-900 / text-green-100

❌ Error:
- Background: bg-red-50 / bg-red-950
- Border: border-red-200 / border-red-800
- Icon: text-red-600 / text-red-400
- Text: text-red-900 / text-red-100

⏳ Loading:
- Icon: text-primary (blue)
- Animation: animate-spin

ℹ️ Info:
- Background: bg-blue-50 / bg-blue-950
- Border: border-blue-200 / border-blue-800
- Icon: text-blue-600 / text-blue-400
```

### **Section Icons**

```
📄 Overview       - text-primary (blue)
🎯 Challenges     - text-primary (blue)
💰 ROI            - text-primary (blue)
💡 Solution       - text-primary (blue)
✅ SOW            - text-primary (blue)
```

---

## 📱 Mobile Responsive Design

### **Desktop (≥768px)**

```
┌──────────────────────────────────────────┐
│ [📄 Overview] [🎯 Challenges] [💰 ROI]  │
│ [💡 Solution] [✅ SOW]                   │
│                                          │
│ All 5 tabs visible side-by-side         │
└──────────────────────────────────────────┘

┌────────────────────┬─────────────────────┐
│ 📄 Gamma Doc       │ ✅ Gamma Deck       │
│                    │                     │
│ [Export Doc]       │ [Export Deck]       │
│                    │                     │
│ ✅ Created [Open]  │ ✅ Created [Open]   │
└────────────────────┴─────────────────────┘
Two-column export layout
```

### **Mobile (<768px)**

```
┌───────────────────────────┐
│ [📄] [🎯] [💰] [💡] [✅] │
│ (Icons only, scrollable)  │
└───────────────────────────┘

┌───────────────────────────┐
│ 📄 Gamma Doc              │
│                           │
│ [Export Doc]              │
│                           │
│ ✅ Created [Open]         │
├───────────────────────────┤
│ ✅ Gamma Deck             │
│                           │
│ [Export Deck]             │
│                           │
│ ✅ Created [Open]         │
└───────────────────────────┘
Stacked export cards
```

---

## 🎯 Interactive Elements

### **Clickable Areas**

```
┌──────────────────────────────────────┐
│ [ Agent Runner ] [ Content Builder ] │
│       ↑                  ↑           │
│   Clickable          Clickable       │
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [📄 Overview ✓] 🎯 Challenges  💰... │
│       ↑              ↑           ↑   │
│   Clickable      Clickable   Clickable
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ 🎯 Challenges & Goals    [Reset]     │
│                              ↑       │
│                          Clickable   │
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [💾 Save All Sections]               │
│        ↑                             │
│    Clickable                         │
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [Export to Gamma Doc]                │
│        ↑                             │
│    Clickable                         │
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ ✅ Created  [Open]                   │
│               ↑                      │
│           Clickable                  │
└──────────────────────────────────────┘
```

### **Hover States**

```
BUTTONS:
Normal:    [Export to Gamma Doc]
Hover:     [Export to Gamma Doc]  ← Slightly darker
                                     + shadow

TABS:
Normal:    [📄 Overview]
Hover:     [📄 Overview]  ← Background highlight

RESET BUTTON:
Normal:    [Reset]
Hover:     [Reset]  ← Border highlight
```

---

## 🎬 Animation Examples

### **Loading Spinner**

```
Frame 1:  [⏳ Creating...]
          └─ Rotated 0°

Frame 2:  [⏳ Creating...]
          └─ Rotated 90°

Frame 3:  [⏳ Creating...]
          └─ Rotated 180°

Frame 4:  [⏳ Creating...]
          └─ Rotated 270°

(Continuous rotation animation)
```

### **Success Transition**

```
Before:
[⏳ Creating...]

Fade Out (100ms)
↓

Fade In (200ms)
↓

After:
✅ Created  [Open]
```

---

## 📐 Layout Measurements

### **Desktop Dimensions**

```
┌────────────────────────────────────────┐
│ Main Container: max-width 1400px       │
│ Padding: 2rem (32px)                   │
│                                        │
│ ┌────────────────────────────────────┐│
│ │ Card: border-radius 10px           ││
│ │ Padding: 24px                      ││
│ │                                    ││
│ │ ┌────────────────────────────────┐││
│ │ │ Textarea: min-height 500px     │││
│ │ │ Font: monospace, 14px          │││
│ │ │ Padding: 12px                  │││
│ │ └────────────────────────────────┘││
│ └────────────────────────────────────┘│
└────────────────────────────────────────┘
```

### **Button Sizes**

```
Large (lg):
- Height: 44px
- Padding: 16px 24px
- Font: 16px

Medium (default):
- Height: 40px
- Padding: 12px 16px
- Font: 14px

Small (sm):
- Height: 32px
- Padding: 8px 12px
- Font: 12px
```

---

**This visual guide shows exactly what the Proposal Content Builder looks like at every step of the user journey!** 🎨
