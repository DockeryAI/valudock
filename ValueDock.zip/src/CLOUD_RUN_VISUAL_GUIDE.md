# Cloud Run Feature - Visual Guide

## 🎯 Feature Location

```
ValueDock App
└── Admin Panel
    └── Proposal Agent Tab
        └── Agent Runner Section
            └── "Run in Cloud" Toggle
```

---

## 📱 UI Screenshots (Text Representation)

### Before: Standard Mode (Cloud Run OFF)

```
┌────────────────────────────────────────────────────┐
│ Agent Configuration                               │
├────────────────────────────────────────────────────┤
│                                                    │
│ Deal ID *                                         │
│ ┌──────────────────────────────────────────────┐ │
│ │ DEAL-2025-001                                │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ Customer Website URL *                            │
│ ┌──────────────────────────────────────────────┐ │
│ │ https://company.com                          │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ Fathom Date Window (Days)                        │
│ ┌──────────────────────────────────────────────┐ │
│ │ Last 30 days                          ▼     │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ ─────────────────────────────────────────────────│
│                                                    │
│ Run in Cloud                          [ ] OFF    │
│ Execute via Supabase Edge Function endpoint      │
│                                                    │
│ ─────────────────────────────────────────────────│
│                                                    │
│ ┌──────────────────┐  ┌──────────────────────┐  │
│ │  ▶ Run Agent     │  │  💾 Run & Save Ver.  │  │
│ └──────────────────┘  └──────────────────────┘  │
│                                                    │
└────────────────────────────────────────────────────┘
```

### After: Cloud Run Mode (Cloud Run ON)

```
┌────────────────────────────────────────────────────┐
│ Agent Configuration                               │
├────────────────────────────────────────────────────┤
│                                                    │
│ Deal ID *                                         │
│ ┌──────────────────────────────────────────────┐ │
│ │ DEAL-2025-001                                │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ Customer Website URL *                            │
│ ┌──────────────────────────────────────────────┐ │
│ │ https://company.com                          │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ Fathom Date Window (Days)                        │
│ ┌──────────────────────────────────────────────┐ │
│ │ Last 30 days                          ▼     │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
│ ─────────────────────────────────────────────────│
│                                                    │
│ Run in Cloud                          [✓] ON     │
│ Execute via Supabase Edge Function endpoint      │
│                                                    │
│ ─────────────────────────────────────────────────│
│                                                    │
│ ┌──────────────────────────────────────────────┐ │
│ │         ▶ Run in Cloud                       │ │
│ └──────────────────────────────────────────────┘ │
│                                                    │
└────────────────────────────────────────────────────┘
```

---

## 🔄 Cloud Run Flow

```
User Action                Backend Process              UI Response
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Toggle ON
   "Run in Cloud"
                              
2. Fill form fields
   
3. Click                    
   "Run in Cloud"           ──→  Validate fields
                                 Calculate dates
                                 
                            ──→  POST /proposal-agent-run
                                 {
                                   tenant_id, org_id,
                                   deal_id, customer_url,
                                   fathom_window: {
                                     start: "2025-09-16",
                                     end: "2025-10-16"
                                   }
                                 }
                                 
                            ──→  Verify auth token
                                 
                            ──→  Store in KV:
                                 proposal-agent-run:<id>
                                 
                            ←──  { 
                                   status: "accepted",
                                   request_id: "...",
                                   timestamp: "..."
                                 }
                                                    ──→  Show Cloud Run Log
                                                         panel with:
                                                         ✅ Green "Accepted" 
                                                         badge
                                                         📅 Timestamp
                                                         📋 JSON response
```

---

## 📊 Cloud Run Log Panel

### Collapsed State

```
┌─────────────────────────────────────────────────────────────┐
│ 📄 Cloud Run Log     [Accepted ✓]               ⌄          │
│ October 16, 2025 at 2:30 PM                                │
└─────────────────────────────────────────────────────────────┘
```

### Expanded State (Success)

```
┌─────────────────────────────────────────────────────────────┐
│ 📄 Cloud Run Log     [Accepted ✓]               ⌃          │
│ October 16, 2025 at 2:30 PM                                │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────┐│
│ │ 📤 Sending cloud run request...                         ││
│ │ {                                                        ││
│ │   "tenant_id": "550e8400-e29b-41d4-a716-446655440000", ││
│ │   "org_id": "660e8400-e29b-41d4-a716-446655440001",    ││
│ │   "deal_id": "DEAL-2025-001",                          ││
│ │   "customer_url": "https://company.com",               ││
│ │   "fathom_window": {                                   ││
│ │     "start": "2025-09-16",                             ││
│ │     "end": "2025-10-16"                                ││
│ │   }                                                     ││
│ │ }                                                       ││
│ │                                                         ││
│ │ 📥 Response received:                                   ││
│ │ {                                                       ││
│ │   "status": "accepted",                                ││
│ │   "request_id": "proposal-run-1729123456789-abc123",  ││
│ │   "timestamp": "2025-10-16T14:30:00.000Z",            ││
│ │   "message": "Proposal agent run request accepted...", ││
│ │   "data": { ... }                                      ││
│ │ }                                                       ││
│ └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

### Expanded State (Error)

```
┌─────────────────────────────────────────────────────────────┐
│ 📄 Cloud Run Log     [Error ✗]                  ⌃          │
│ October 16, 2025 at 2:30 PM                                │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────┐│
│ │ 📤 Sending cloud run request...                         ││
│ │ { ... }                                                 ││
│ │                                                         ││
│ │ 📥 Response received:                                   ││
│ │ {                                                       ││
│ │   "status": "error",                                   ││
│ │   "error": "Missing required fields",                  ││
│ │   "timestamp": "2025-10-16T14:30:00.000Z",            ││
│ │   "required": [                                        ││
│ │     "tenant_id", "org_id", "deal_id",                 ││
│ │     "customer_url", "fathom_window"                   ││
│ │   ]                                                     ││
│ │ }                                                       ││
│ │                                                         ││
│ │ ❌ Error: Missing required fields                      ││
│ └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

---

## 🎨 Color Coding

| Element | Color | Meaning |
|---------|-------|---------|
| 🟢 Green Badge | Success | `status === "accepted"` |
| 🔴 Red Badge | Error | `status !== "accepted"` |
| 🔵 Blue Border | Cloud Run | Active cloud run log panel |
| ⚪ Gray Text | Info | Timestamps and descriptions |

---

## 🔢 Status Badge Examples

```
Success:    [ Accepted ✓ ]     (Green background, white text)
            
Error:      [ Error ✗ ]        (Red background, white text)
            
Rejected:   [ Rejected ✗ ]     (Red background, white text)
            
Pending:    [ Pending ⏳ ]      (Orange background, white text)
```

---

## 💡 User Interactions

### Toggle Switch

```
OFF State:               ON State:
┌─────────────┐         ┌─────────────┐
│  ○──────    │  →→→→→  │    ──────●  │
└─────────────┘         └─────────────┘
```

### Collapsible Panel

```
Collapsed:                    Expanded:
Click to expand ⌄      →      Click to collapse ⌃
Shows header only              Shows full content
```

### Button States

```
Ready:          Loading:           Disabled:
┌──────────┐    ┌──────────┐      ┌──────────┐
│ ▶ Run in │    │ ⏳ Running│      │  ▶ Run   │
│   Cloud  │    │   in Cloud│      │  (gray)  │
└──────────┘    └──────────┘      └──────────┘
```

---

## 📋 Quick Reference Table

| Toggle State | Buttons Shown | Log Panel Visible | Behavior |
|--------------|---------------|-------------------|----------|
| OFF | "Run Agent" + "Run & Save Version" | No | Standard agent execution |
| ON | "Run in Cloud" (full width) | After response | POST to cloud endpoint |

---

## 🚀 Step-by-Step Visual Walkthrough

### Step 1: Navigate to Proposal Agent
```
Admin Panel → Tabs → [Proposal Agent]
```

### Step 2: Locate the Cloud Run Toggle
```
Scroll down in "Agent Configuration" card
Look for: "Run in Cloud" with switch
```

### Step 3: Enable Cloud Run
```
Click toggle switch: OFF → ON
Watch UI update: 2 buttons → 1 button
```

### Step 4: Fill Required Fields
```
✓ Deal ID
✓ Customer URL
✓ Fathom Window
✓ Organization (if admin)
```

### Step 5: Click Run in Cloud
```
Button changes: "Run in Cloud" → "Running in Cloud..."
Loading spinner appears
```

### Step 6: View Response
```
New panel appears below (blue border)
Click header to expand/collapse
Check green badge for success
Read JSON response in log area
```

---

## 🎯 Visual Indicators

### When Cloud Run is Active:
- ✅ Toggle switch shows ON (blue/green)
- ✅ Single button displayed (full width)
- ✅ Button text: "Run in Cloud"
- ✅ Log panel appears after response

### When Cloud Run is Inactive:
- ⭕ Toggle switch shows OFF (gray)
- ⭕ Two buttons displayed (side-by-side)
- ⭕ Button texts: "Run Agent" and "Run & Save Version"
- ⭕ No cloud log panel

---

**Version**: 1.0  
**Last Updated**: 2025-10-16  
**Component**: `ProposalAgentRunner.tsx`
