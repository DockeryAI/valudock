# Proposal Agent Test Features - Visual Guide

## 🎨 Complete UI Walkthrough

This guide shows exactly what users will see when using the new test and debugging features.

---

## 📱 Main Interface

### **Tab Navigation (Updated)**

```
┌──────────────────────────────────────────────────────────────┐
│                     Proposal Builder                          │
├──────────────────────────────────────────────────────────────┤
│ [ Agent Runner ] [ Content Builder ] [ 📜 Versions Log ]     │
└──────────────────────────────────────────────────────────────┘
                ↑                            ↑
             Existing                      NEW!
```

---

## 🚀 Agent Runner Tab (Updated)

### **Before (Old Layout)**
```
┌─────────────────────────────────────────────────┐
│ Agent Configuration                             │
│                                                 │
│ Deal ID: [________________________]             │
│ URL:     [________________________]             │
│ Window:  [Last 30 days ▼]                       │
│                                                 │
│ [Run Agent]    [Run & Save Version]             │
└─────────────────────────────────────────────────┘
```

### **After (New Layout with Test Features)**
```
┌─────────────────────────────────────────────────┐
│ Agent Configuration                             │
│                                                 │
│ Deal ID: [________________________]             │
│ URL:     [________________________]             │
│ Window:  [Last 30 days ▼]                       │
│                                                 │
│ ┌─────────────────────────────────────────────┐ │
│ │ Use OpenAI REST (no SDK)           [⚪ OFF] │ │  ← NEW!
│ │ Direct HTTP calls with logging             │ │
│ └─────────────────────────────────────────────┘ │
│                                                 │
│ [🧪 Test Run]      [🧪 Smoke Test]             │  ← NEW!
│ ─────────────────────────────────────────────   │
│ [▶ Run Agent]      [💾 Run & Save Version]      │
└─────────────────────────────────────────────────┘
```

---

## 🧪 Test Run Feature

### **Step 1: Before Click**
```
┌─────────────────────────────────────────────────┐
│ [🧪 Test Run]      [🧪 Smoke Test]             │
│         ↑                                       │
│    Click here                                   │
└─────────────────────────────────────────────────┘
```

### **Step 2: Running (Button State)**
```
┌─────────────────────────────────────────────────┐
│ [⏳ Testing...]    [🧪 Smoke Test]             │
│  (Disabled)       (Disabled while test runs)   │
└─────────────────────────────────────────────────┘
```

### **Step 3: Console Log Appears**
```
┌─────────────────────────────────────────────────┐
│ 🧪 Test Run Console                             │
├─────────────────────────────────────────────────┤
│ 🚀 Starting Test Run...                        │
│ 📋 Using placeholder IDs: deal-test-001...     │
│ 🌐 Fetching site → Analyzing customer...       │
│ ✅ Website analysis complete                    │
│ 💰 Analyzing ROI → Calculating metrics...      │
│ ✅ ROI calculation complete                     │
│ 💾 Saving version → Persisting to database...  │
│ ✅ Version saved successfully                   │
│ ✨ Test Run Complete!                          │
│                                                 │
│ [▼ Show Final Output]                           │
│         ↑                                       │
│    Collapsible panel                            │
└─────────────────────────────────────────────────┘
```

### **Step 4: Output Expanded**
```
┌─────────────────────────────────────────────────┐
│ [▲ Hide Final Output]                           │
├─────────────────────────────────────────────────┤
│ Test Run Completed Successfully!                │
│                                                 │
│ Deal ID: deal-test-001                          │
│ Organization: org-test-001                      │
│ Customer URL: https://example.com               │
│                                                 │
│ ✅ Website fetched and analyzed                │
│ ✅ Meeting transcripts processed               │
│ ✅ ROI calculations performed                  │
│ ✅ Proposal data generated                     │
│                                                 │
│ Final Output: This is a test proposal          │
│ generated with placeholder data.                │
│ All systems operational and ready for           │
│ production use.                                 │
│                                                 │
│ API Mode: OpenAI SDK                            │
└─────────────────────────────────────────────────┘
```

---

## 🧪 Smoke Test Feature

### **Console Log Display**
```
┌─────────────────────────────────────────────────┐
│ 🧪 Smoke Test Console                           │
├─────────────────────────────────────────────────┤
│ 🧪 Starting Smoke Test...                      │
│ 🌐 fetch_url → Retrieving customer data...     │
│ ✅ fetch_url complete                          │
│ 🎤 fathom.get_meetings → Searching...          │
│ ✅ fathom.get_meetings complete                │
│ 🎤 fathom.get_summary → Extracting insights... │
│ ✅ fathom.get_summary complete                 │
│ 💾 valuedock.put_proposal → Saving data...     │
│ ✅ valuedock.put_proposal complete             │
│ 🎨 gamma.create_deck → Generating...           │
│ ✅ gamma.create_deck complete                  │
│ ✨ Smoke Test Complete!                        │
│                                                 │
│ [▼ Show Assistant Text]                         │
└─────────────────────────────────────────────────┘
```

### **Assistant Text Output**
```
┌─────────────────────────────────────────────────┐
│ [▲ Hide Assistant Text]                         │
├─────────────────────────────────────────────────┤
│ Smoke Test Report                               │
│ ================                                │
│                                                 │
│ All tools executed successfully:                │
│                                                 │
│ 1. fetch_url: Retrieved customer website data  │
│ 2. fathom.get_meetings: Found 3 relevant       │
│    meetings                                     │
│ 3. fathom.get_summary: Extracted key insights  │
│    and challenges                               │
│ 4. valuedock.put_proposal: Saved proposal      │
│    data to database                             │
│ 5. gamma.create_deck: Generated presentation   │
│    link                                         │
│                                                 │
│ API Configuration: OpenAI SDK                   │
│                                                 │
│ Status: ✅ All systems operational             │
│ Timestamp: 2025-10-16T14:30:00Z                │
└─────────────────────────────────────────────────┘
```

---

## 📜 Versions Log Tab (NEW!)

### **Empty State**
```
┌─────────────────────────────────────────────────┐
│ 📜 Version Activity Log                         │
│ View saved versions with metadata               │
├─────────────────────────────────────────────────┤
│                                                 │
│              📜                                 │
│                                                 │
│    No versions yet. Create a deal and           │
│    run the agent to begin.                      │
│                                                 │
└─────────────────────────────────────────────────┘
```

### **With Versions**
```
┌─────────────────────────────────────────────────┐
│ 📜 Version Activity Log                         │
│ View saved versions with metadata               │
├─────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────┐ │
│ │ Version 3  [Draft] [Current]                │ │
│ │ Created Oct 16, 2025 2:30:15 PM             │ │
│ │                          [👁️ View JSON]     │ │
│ │                                             │ │
│ │ Created by: John Doe                        │ │
│ │ Version ID: deal-001-v3-1729089615123       │ │
│ └─────────────────────────────────────────────┘ │
│                                                 │
│ ┌─────────────────────────────────────────────┐ │
│ │ Version 2  [Published]                      │ │
│ │ Created Oct 15, 2025 10:15:30 AM            │ │
│ │                          [👁️ View JSON]     │ │
│ │                                             │ │
│ │ Created by: Jane Smith                      │ │
│ │ Version ID: deal-001-v2-1728994530456       │ │
│ └─────────────────────────────────────────────┘ │
│                                                 │
│ ┌─────────────────────────────────────────────┐ │
│ │ Version 1  [Draft]                          │ │
│ │ Created Oct 14, 2025 3:45:00 PM             │ │
│ │                          [👁️ View JSON]     │ │
│ │                                             │ │
│ │ Created by: John Doe                        │ │
│ │ Version ID: deal-001-v1-1728916700789       │ │
│ └─────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

### **View JSON Action**
```
User clicks [View JSON]
           ↓
Browser Console opens:
┌─────────────────────────────────────────────────┐
│ Console                                         │
├─────────────────────────────────────────────────┤
│ Version data: {                                 │
│   id: "deal-001-v3-1729089615123",              │
│   version: 3,                                   │
│   status: "draft",                              │
│   createdAt: "2025-10-16T14:30:15.123Z",        │
│   createdBy: "user-123",                        │
│   createdByName: "John Doe",                    │
│   dealId: "deal-001",                           │
│   organizationId: "org-456",                    │
│   presentationData: { ... },                    │
│   logs: [ ... ]                                 │
│ }                                               │
└─────────────────────────────────────────────────┘
           ↓
Toast notification:
┌─────────────────────────────────────┐
│ ✅ Version data logged to console  │
└─────────────────────────────────────┘
```

---

## 🔧 OpenAI REST Toggle

### **Toggle OFF (Default)**
```
┌─────────────────────────────────────────────────┐
│ Use OpenAI REST (no SDK)           [⚪ OFF]    │
│ Direct HTTP calls with logging                 │
└─────────────────────────────────────────────────┘
```

### **Toggle ON (Debug Mode)**
```
┌─────────────────────────────────────────────────┐
│ Use OpenAI REST (no SDK)           [🟢 ON]     │
│ Direct HTTP calls with logging                 │
└─────────────────────────────────────────────────┘
```

### **Console Logs (When ON)**
```
Console Output:
┌─────────────────────────────────────────────────┐
│ [OpenAI REST] Request:                          │
│ {                                               │
│   url: "https://api.openai.com/v1/responses",  │
│   method: "POST",                               │
│   headers: {                                    │
│     "Authorization": "Bearer sk-...",           │
│     "Content-Type": "application/json"          │
│   },                                            │
│   timestamp: "2025-10-16T14:30:00Z"             │
│ }                                               │
│                                                 │
│ [OpenAI REST] Response:                         │
│ {                                               │
│   status: 200,                                  │
│   headers: { ... },                             │
│   body: { ... },                                │
│   timestamp: "2025-10-16T14:30:02Z"             │
│ }                                               │
└─────────────────────────────────────────────────┘
```

---

## 🎬 Complete User Flow

### **Flow 1: Daily Smoke Test**

```
Step 1: Open Proposal Agent
┌─────────────────────────────────────┐
│ Admin → Agent → Proposal Builder    │
└─────────────────────────────────────┘
          ↓
Step 2: Click Smoke Test
┌─────────────────────────────────────┐
│ [🧪 Smoke Test]                     │
│         ↑                           │
│     Click here                      │
└─────────────────────────────────────┘
          ↓
Step 3: Watch Console Log
┌─────────────────────────────────────┐
│ 🧪 Starting Smoke Test...          │
│ 🌐 fetch_url → ✅                  │
│ 🎤 fathom.get_meetings → ✅        │
│ 🎤 fathom.get_summary → ✅         │
│ 💾 valuedock.put_proposal → ✅     │
│ 🎨 gamma.create_deck → ✅          │
│ ✨ Complete!                       │
└─────────────────────────────────────┘
          ↓
Step 4: See Toast
┌─────────────────────────────────────┐
│ ✅ Smoke test completed!           │
└─────────────────────────────────────┘
```

### **Flow 2: Debug Failed Proposal**

```
Step 1: Enable Debug Mode
┌─────────────────────────────────────┐
│ Use OpenAI REST (no SDK)  [⚪→🟢]  │
│         ↑                           │
│     Toggle ON                       │
└─────────────────────────────────────┘
          ↓
Step 2: Run Test
┌─────────────────────────────────────┐
│ [🧪 Test Run]                       │
│         ↑                           │
│     Click here                      │
└─────────────────────────────────────┘
          ↓
Step 3: Check Console
┌─────────────────────────────────────┐
│ [OpenAI REST] Request: { ... }      │
│ [OpenAI REST] Response: {           │
│   status: 429,                      │
│   error: "Rate limit exceeded"      │
│ }                                   │
└─────────────────────────────────────┘
          ↓
Step 4: Identify Issue
┌─────────────────────────────────────┐
│ Root cause: Rate limit hit          │
│ Solution: Wait or upgrade plan      │
└─────────────────────────────────────┘
```

### **Flow 3: Version Audit**

```
Step 1: Switch to Versions Tab
┌─────────────────────────────────────┐
│ [ Agent Runner ]                    │
│ [ Content Builder ]                 │
│ [ 📜 Versions Log ] ← Click         │
└─────────────────────────────────────┘
          ↓
Step 2: Find Version
┌─────────────────────────────────────┐
│ Version 2  [Published]              │
│ Oct 15, 2025 10:15 AM               │
│              [View JSON] ← Click    │
│                                     │
│ Created by: Jane Smith              │
└─────────────────────────────────────┘
          ↓
Step 3: Check Console
┌─────────────────────────────────────┐
│ Version data: {                     │
│   version: 2,                       │
│   status: "published",              │
│   createdBy: "Jane Smith",          │
│   presentationData: { ... }         │
│ }                                   │
└─────────────────────────────────────┘
          ↓
Step 4: Audit Complete
┌─────────────────────────────────────┐
│ ✅ Version verified                │
│ All data intact                     │
└─────────────────────────────────────┘
```

---

## 🎯 Interactive States

### **Button States**

#### **Test Run Button**
```
Idle:     [🧪 Test Run]
Running:  [⏳ Testing...] (disabled)
Done:     [🧪 Test Run]
```

#### **Smoke Test Button**
```
Idle:     [🧪 Smoke Test]
Running:  [⏳ Testing...] (disabled)
Done:     [🧪 Smoke Test]
```

#### **View JSON Button**
```
Idle:     [👁️ View JSON]
Clicked:  [👁️ View JSON] (no visual change)
          Opens console + shows toast
```

### **Collapsible States**

#### **Collapsed**
```
[▼ Show Final Output]
```

#### **Expanded**
```
[▲ Hide Final Output]
├───────────────────────┐
│ Output content here   │
│ ...                   │
└───────────────────────┘
```

---

## 📱 Mobile View

### **Stacked Layout**
```
┌───────────────────────┐
│ Agent Configuration   │
│                       │
│ Deal ID:              │
│ [__________________]  │
│                       │
│ URL:                  │
│ [__________________]  │
│                       │
│ ┌───────────────────┐ │
│ │ OpenAI REST  [🟢] │ │
│ │ HTTP logging      │ │
│ └───────────────────┘ │
│                       │
│ [🧪 Test Run]        │
│                       │
│ [🧪 Smoke Test]      │
│                       │
│ ─────────────────────  │
│                       │
│ [▶ Run Agent]         │
│                       │
│ [💾 Run & Save]       │
└───────────────────────┘
```

---

## 🎨 Color Coding

### **Status Colors**

```
✅ Success:
- Icon: Green (#22c55e)
- Background: bg-green-50 / bg-green-950

❌ Error:
- Icon: Red (#ef4444)
- Background: bg-red-50 / bg-red-950

⏳ Running:
- Icon: Blue (#3b82f6)
- Animation: Spinning

🧪 Test:
- Icon: Purple (#a855f7)
- Background: Secondary

📜 Version:
- Icon: Gray (#6b7280)
- Background: Muted
```

---

**This visual guide shows exactly what the Proposal Agent test features look like at every step!** 🎨
