# Sync Cloud Secrets - Visual Walkthrough

## 🎬 Complete Visual Flow

---

## Scenario: First-Time Setup (All Secrets Ready)

### Step 1: Navigate to Proposal Agent Admin

```
┌──────────────────────────────────────────────────────────────┐
│ Admin Dashboard                                              │
├──────────────────────────────────────────────────────────────┤
│ [Users] [Groups] [Webhooks] [Proposal Agent] [Secrets] ... │
│                              ▲                                │
│                              └─ Click here                    │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 2: Enable Cloud Run

```
┌──────────────────────────────────────────────────────────────┐
│ Agent Configuration                                          │
├──────────────────────────────────────────────────────────────┤
│ Run in Cloud                            [✓ ON]               │
│                                         ▲                     │
│                                         └─ Toggle ON          │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 3: Expand Cloud Run Console

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌄   │ ← Click
│ Deploy and test the Edge Function                           │
└──────────────────────────────────────────────────────────────┘

                        ↓ Expands to ↓

┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
│ Deploy and test the Edge Function                           │
├──────────────────────────────────────────────────────────────┤
│ ┌────────────┐  ┌──────────────┐  ┌──────────────┐         │
│ │✓ Sync      │  │🧪 Test Edge  │  │✓ Verify      │ ...     │
│ │  Secrets   │  │  Function    │  │  Secrets     │         │
│ └────────────┘  └──────────────┘  └──────────────┘         │
│        ▲                                                     │
│        └─ Click this blue button                            │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 4: Click "Sync Secrets"

**Before Click:**
```
┌────────────┐
│✓ Sync      │
│  Secrets   │
└────────────┘
```

**During Sync (3-5 seconds):**
```
┌────────────┐
│⟳ Syncing...│
└────────────┘
```

---

### Step 5: Watch Progress in Log

```
┌──────────────────────────────────────────────────────────────┐
│ Deployment Log                                               │
├──────────────────────────────────────────────────────────────┤
│ 🔄 Syncing secrets to cloud...                              │
│ 📤 Syncing 5 secrets to edge function...                    │
│                                                              │
│ 📥 Sync Response:                                            │
│ {                                                            │
│   "success": true,                                          │
│   "message": "✅ All secrets synced successfully",          │
│   "syncedSecrets": {                                        │
│     "OPENAI_API_KEY": true,                                 │
│     "SUPABASE_URL": true,                                   │
│     "SUPABASE_SERVICE_ROLE_KEY": true,                      │
│     "GAMMA_API_KEY": true,                                  │
│     "FATHOM_API_KEY": true                                  │
│   },                                                         │
│   "allSynced": true,                                        │
│   "timestamp": "2025-10-16T15:30:00.000Z"                   │
│ }                                                            │
│                                                              │
│ ✅ Secrets synced successfully!                             │
│                                                              │
│ 🔍 Auto-verifying secrets...                                │
│                                                              │
│ 📤 Sending verification request...                          │
│ 📥 Verification Response:                                    │
│ {                                                            │
│   "status": "verified",                                     │
│   "message": "✅ All secrets loaded successfully",          │
│   "secretsStatus": {                                        │
│     "openai": true,                                         │
│     "supabaseUrl": true,                                    │
│     "supabaseServiceRole": true,                            │
│     "gamma": true,                                          │
│     "fathom": true                                          │
│   },                                                         │
│   "allSecretsLoaded": true                                  │
│ }                                                            │
│                                                              │
│ ✅ Verification successful!                                 │
│                                                              │
│ 📋 Secrets Status:                                          │
│   OpenAI: ✅                                                │
│   Supabase URL: ✅                                          │
│   Supabase Service Role: ✅                                 │
│   Gamma: ✅                                                 │
│   Fathom: ✅                                                │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 6: View Results - SUCCESS! ✅

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
├──────────────────────────────────────────────────────────────┤
│ ┌────────────┐  ┌──────────────┐  ┌──────────────┐ ...     │
│ │✓ Sync      │  │🧪 Test Edge  │  │✓ Verify      │         │
│ │  Secrets   │  │  Function    │  │  Secrets     │         │
│ └────────────┘  └──────────────┘  └──────────────┘         │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ Sync Results                                           │  │
│ │                                                        │  │
│ │ ✅ All secrets synced successfully  [All Synced ✓]    │  │
│ │                                                        │  │
│ │ ┌──────────────────────────────────────────────────┐  │  │
│ │ │ OpenAI                                       ✅  │  │  │
│ │ │ Supabase URL (ValueDock)                     ✅  │  │  │
│ │ │ Supabase Service Role (ValueDock)            ✅  │  │  │
│ │ │ Gamma                                        ✅  │  │  │
│ │ │ Fathom                                       ✅  │  │  │
│ │ └──────────────────────────────────────────────────┘  │  │
│ │                                                        │  │
│ │ ℹ️ Secrets stored successfully                        │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ✅ Edge Function: Connected    [Connected ✓]          │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ Secrets Loaded                                         │  │
│ │                                                        │  │
│ │ ┌──────────────────────────────────────────────────┐  │  │
│ │ │ OpenAI                                       ✅  │  │  │
│ │ │ Supabase URL (ValueDock)                     ✅  │  │  │
│ │ │ Supabase Service Role (ValueDock)            ✅  │  │  │
│ │ │ Gamma                                        ✅  │  │  │
│ │ │ Fathom                                       ✅  │  │  │
│ │ └──────────────────────────────────────────────────┘  │  │
│ └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘

         ↓ Toast notifications ↓

┌──────────────────────────────────────────────────────────────┐
│ ✅ Secrets synced! Verifying...                              │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ ✅ All secrets verified! ✅                                  │
└──────────────────────────────────────────────────────────────┘
```

---

## Scenario 2: Partial Sync (Some Secrets Missing)

### Step 6: View Results - PARTIAL ⚠️

```
┌──────────────────────────────────────────────────────────────┐
│ 🔧 Cloud Run Console                                    ⌃   │
├──────────────────────────────────────────────────────────────┤
│ ┌────────────────────────────────────────────────────────┐  │
│ │ Sync Results                                           │  │
│ │                                                        │  │
│ │ ⚠️ Some secrets were not provided                     │  │
│ │                                                        │  │
│ │ ┌──────────────────────────────────────────────────┐  │  │
│ │ │ OpenAI                                       ✅  │  │  │
│ │ │ Supabase URL (ValueDock)                     ✅  │  │  │
│ │ │ Supabase Service Role (ValueDock)            ✅  │  │  │
│ │ │ Gamma                                        ❌  │  │  │
│ │ │ Fathom                                       ❌  │  │  │
│ │ └──────────────────────────────────────────────────┘  │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ ✅ Edge Function: Connected    [Connected ✓]          │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ Secrets Loaded                      [⚠ Fix in Admin]  │  │
│ │                                             ▲          │  │
│ │                                             └─ Click   │  │
│ │ ┌──────────────────────────────────────────────────┐  │  │
│ │ │ OpenAI                                       ✅  │  │  │
│ │ │ Supabase URL (ValueDock)                     ✅  │  │  │
│ │ │ Supabase Service Role (ValueDock)            ✅  │  │  │
│ │ │ Gamma                                        ❌  │  │  │
│ │ │ Fathom                                       ❌  │  │  │
│ │ └──────────────────────────────────────────────────┘  │  │
│ │                                                        │  │
│ │ ┌──────────────────────────────────────────────────┐  │  │
│ │ │ ⚠️ Some secrets are missing  [Missing Secrets]   │  │  │
│ │ └──────────────────────────────────────────────────┘  │  │
│ └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘

         ↓ Toast notification ↓

┌──────────────────────────────────────────────────────────────┐
│ ⚠️ Some secrets are still missing                            │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 7: Fix Missing Secrets

```
Click "Fix in Admin" button (or navigate manually)
                ↓
┌──────────────────────────────────────────────────────────────┐
│ Admin Dashboard                                              │
├──────────────────────────────────────────────────────────────┤
│ [Users] [Groups] [Webhooks] [Proposal Agent] [Secrets] ... │
│                                               ▲              │
│                                               └─ Click       │
└──────────────────────────────────────────────────────────────┘
                ↓
┌──────────────────────────────────────────────────────────────┐
│ Secrets Management                                           │
├──────────────────────────────────────────────────────────────┤
│ Gamma API Key                     [Not Configured ✗]        │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ gamma_key_here                                         │  │ ← Add
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ Fathom API Key                    [Not Configured ✗]        │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ fathom_key_here                                        │  │ ← Add
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│                                        [Save Secrets]        │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 8: Return and Re-Sync

```
Back to: Admin → Proposal Agent → Cloud Run Console

Click: "Sync Secrets" again
                ↓

┌──────────────────────────────────────────────────────────────┐
│ Sync Results                                                 │
│                                                              │
│ ✅ All secrets synced successfully  [All Synced ✓]          │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ OpenAI                                             ✅  │  │
│ │ Supabase URL (ValueDock)                           ✅  │  │
│ │ Supabase Service Role (ValueDock)                  ✅  │  │
│ │ Gamma                                              ✅  │  │ ← Fixed!
│ │ Fathom                                             ✅  │  │ ← Fixed!
│ └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## 🎯 Side-by-Side Comparison

### Sync Results Panel
```
Shows what YOU sent:
┌───────────────────────┐
│ OpenAI           ✅  │
│ Supabase URL     ✅  │
│ Supabase Role    ✅  │
│ Gamma            ✅  │
│ Fathom           ✅  │
└───────────────────────┘
```

### Secrets Loaded Panel
```
Shows what EDGE FUNCTION sees:
┌───────────────────────┐
│ OpenAI           ✅  │
│ Supabase URL     ✅  │
│ Supabase Role    ✅  │
│ Gamma            ✅  │
│ Fathom           ✅  │
└───────────────────────┘
```

**Both should match!** ✅

---

## 🔄 Complete Button Layout

```
┌──────────────────────────────────────────────────────────────┐
│ Cloud Run Console Action Buttons                            │
├──────────────────────────────────────────────────────────────┤
│ ┌────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────┐│
│ │✓ Sync      │  │🧪 Test Edge  │  │✓ Verify      │  │🔧   ││
│ │  Secrets   │  │  Function    │  │  Secrets     │  │Depl ││
│ └────────────┘  └──────────────┘  └──────────────┘  └─────┘│
│      ↓                ↓                  ↓              ↓    │
│   Push to         Test HTTP         Check env       Deploy  │
│   cloud           connectivity       variables      function │
└──────────────────────────────────────────────────────────────┘
```

**Recommended Order:**
1. Sync Secrets
2. Verify Secrets (auto-triggered)
3. Test Edge Function
4. Deploy Edge Function (if needed)

---

## 📊 Visual Status Indicators

### Badges

**All Good:**
```
[All Synced ✓]    Green background
[Connected ✓]     Green background
```

**Partial:**
```
[Missing Secrets]  Yellow outline
```

**Failed:**
```
[Sync Failed]      Red background
[Not Connected]    Red background
```

---

### Checkmarks

**Present:**
```
✅  Green circle with check
```

**Missing:**
```
❌  Red circle with X
```

---

### Toast Positions

```
┌──────────────────────────────────────────────────────────────┐
│                                          ┌─────────────────┐ │
│                                          │ ✅ Toast 1      │ │
│                                          └─────────────────┘ │
│                                          ┌─────────────────┐ │
│                                          │ ✅ Toast 2      │ │
│                                          └─────────────────┘ │
│                                                              │
│ [Main Content]                                               │
└──────────────────────────────────────────────────────────────┘
```

Toasts appear in top-right and stack vertically.

---

## 💡 Visual Cues to Watch For

### During Sync
```
Button text: "⟳ Syncing..."
Log updates in real-time
Toast: "Secrets synced! Verifying..."
```

### After Sync
```
Blue info box with note
Green checks appear
Auto-verification starts
Second toast appears
```

### After Verification
```
"Secrets Loaded" panel populates
All 5 items show status
Final toast confirmation
```

---

## 🎬 Animation Sequence

```
Click "Sync Secrets"
        ↓
Button spins (⟳ Syncing...)
        ↓
Log scrolls with updates
        ↓
"Sync Results" panel appears
        ↓
Green checks populate
        ↓
Toast #1: "Secrets synced! Verifying..."
        ↓
Auto-verification starts
        ↓
"Secrets Loaded" panel appears
        ↓
Green checks populate again
        ↓
Toast #2: "All secrets verified! ✅"
        ↓
Complete! ✅
```

**Total Time:** 3-5 seconds

---

## 🔍 Debugging Visual Clues

### All Green ✅
```
Everything working correctly
Ready to use
No action needed
```

### Some Red ❌
```
Missing secrets identified
Go to Admin → Secrets
Add missing keys
Sync again
```

### Edge Function Connected but Secrets Missing
```
Function deployed ✅
But secrets not synced ❌
Solution: Click "Sync Secrets"
```

---

**Navigation Summary:**
```
Admin → Proposal Agent → Run in Cloud (ON) → Cloud Run Console → Sync Secrets → ✅
```

**Success Criteria:**
```
✅ "All Synced ✓" badge
✅ All 5 green in "Sync Results"
✅ All 5 green in "Secrets Loaded"
✅ Two success toasts
```

---

**Last Updated:** 2025-10-16  
**Version:** 1.0  
**Full Guide:** `SYNC_CLOUD_SECRETS_GUIDE.md`  
**Quick Ref:** `SYNC_SECRETS_QUICK_REF.md`
