# 📊 Proposal Run Log - Visual Guide

## 🎨 Desktop Layout

```
┌────────────────────────────────────────────────────────────────────────────────────┐
│                          ValuDock® - Proposal Builder                              │
│  Build a comprehensive C-level presentation with ROI data...    [Version v2.1 ▼]   │
├───────────────────────────────────────────────────┬────────────────────────────────┤
│                                                   │        Run Log                 │
│  [Executive][Solution][About][Costs][SOW][Preview]│   ┌──────────────────────┐   │
│                                                   │   │ Discovery → ROI →    │   │
│  ┌─────────────────────────────────────────────┐ │   │ Solution → Export    │   │
│  │ Executive Summary                           │ │   │ [▓▓▓▓▓░░░░░░░░░░]  │   │
│  │                                             │ │   └──────────────────────┘   │
│  │ Company Website:                            │ │                              │
│  │ ┌─────────────────────────────────────────┐ │ │   🔍 Filter by Run ID...     │
│  │ │ https://acmecorp.com                    │ │ │   ┌─ Tenant: tenant-001      │
│  │ └─────────────────────────────────────────┘ │ │   └─ Org: org-456            │
│  │                                             │ │                              │
│  │ Business Description:                       │ │   ╔═══════════════════════╗  │
│  │ ┌─────────────────────────────────────────┐ │ │   ║ [Discovery] ✓         ║  │
│  │ │ Acme Corp is a leading provider of...   │ │ │   ║ Fetch Fathom Meetings ║  │
│  │ │                                         │ │ │   ║ 12:34:56      2.3s    ║  │
│  │ │                                         │ │ │   ║ Found 3 meetings      ║  │
│  │ │                                         │ │ │   ╚═══════════════════════╝  │
│  │ └─────────────────────────────────────────┘ │ │                              │
│  │                                             │ │   ╔═══════════════════════╗  │
│  │ Meeting History:                            │ │   ║ [Discovery] ✓         ║  │
│  │ ┌─────────────────────────────────────────┐ │ │   ║ Extract Challenges    ║  │
│  │ │ • Meeting 1 - Oct 15, 2025             │ │ │   ║ 12:34:58      1.8s    ║  │
│  │ │ • Meeting 2 - Oct 16, 2025             │ │ │   ║ Extracted 5 items     ║  │
│  │ └─────────────────────────────────────────┘ │ │   ╚═══════════════════════╝  │
│  │                                             │ │                              │
│  │ Challenges & Goals:                         │ │   ╔═══════════════════════╗  │
│  │                                             │ │   ║ [ROI] ⟳ Running       ║  │
│  │ Goals:                                      │ │   ║ Calculate ROI Stats   ║  │
│  │ ┌─────────────────────────────────────────┐ │ │   ║ 12:35:00    Running   ║  │
│  │ │ + Reduce operational costs by 30%       │ │ │   ║                       ║  │
│  │ │ + Improve customer satisfaction         │ │ │   ╚═══════════════════════╝  │
│  │ └─────────────────────────────────────────┘ │ │                              │
│  │                                             │ │   ╔═══════════════════════╗  │
│  │                                             │ │   ║ [ROI] ○ Pending       ║  │
│  │                                             │ │   ║ Generate Summary      ║  │
│  └─────────────────────────────────────────────┘ │   ║ -             -       ║  │
│                                                   │   ║                       ║  │
│                  Main Content (2/3 width)         │   ╚═══════════════════════╝  │
│                                                   │                              │
│                                                   │   5 log entries              │
│                                                   │   [✓] Auto-refresh           │
│                                                   │                              │
│                                                   │   Run Log Panel (1/3 width)  │
└───────────────────────────────────────────────────┴────────────────────────────────┘
```

---

## 📱 Mobile Layout

```
┌──────────────────────────────────────┐
│    ValuDock® - Proposal Builder     │
│  [Version v2.1 ▼]                    │
├──────────────────────────────────────┤
│                                      │
│ [Executive][Solution][About]...      │
│                                      │
│ ┌──────────────────────────────────┐ │
│ │ Executive Summary                │ │
│ │                                  │ │
│ │ Company Website:                 │ │
│ │ ┌──────────────────────────────┐ │ │
│ │ │ https://acmecorp.com         │ │ │
│ │ └──────────────────────────────┘ │ │
│ │                                  │ │
│ │ Business Description:            │ │
│ │ ┌──────────────────────────────┐ │ │
│ │ │ Acme Corp is a leading...    │ │ │
│ │ │                              │ │ │
│ │ └──────────────────────────────┘ │ │
│ │                                  │ │
│ └──────────────────────────────────┘ │
│                                      │
│          Main Content                │
│         (Full Width)                 │
│                                      │
├──────────────────────────────────────┤
│                                      │
│ ┌──────────────────────────────────┐ │
│ │        Run Log                   │ │
│ │                                  │ │
│ │ Discovery → ROI → Solution → ...│ │
│ │ [▓▓▓▓▓░░░░░░░░░░]              │ │
│ │                                  │ │
│ │ 🔍 Filter by Run ID...           │ │
│ │                                  │ │
│ │ ╔══════════════════════════════╗ │ │
│ │ ║ [Discovery] ✓                ║ │ │
│ │ ║ Fetch Fathom Meetings        ║ │ │
│ │ ║ 12:34:56          2.3s       ║ │ │
│ │ ╚══════════════════════════════╝ │ │
│ │                                  │ │
│ │ ╔══════════════════════════════╗ │ │
│ │ ║ [ROI] ⟳ Running              ║ │ │
│ │ ║ Calculate Stats              ║ │ │
│ │ ╚══════════════════════════════╝ │ │
│ │                                  │ │
│ └──────────────────────────────────┘ │
│                                      │
│        Run Log Panel                 │
│       (Full Width, Below)            │
│                                      │
└──────────────────────────────────────┘
```

---

## 🎨 Run Log Panel Components

### Progress Bar with Phases

```
┌────────────────────────────────────────┐
│ Discovery → ROI → Solution → Export    │
│ ▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░   │
└────────────────────────────────────────┘
    ↑           ↑
  25% done   Current phase
```

**Colors**:
- Active phase: Primary color (bold)
- Inactive phases: Muted color
- Progress bar: Primary gradient

---

### Filter Section

```
┌────────────────────────────────────────┐
│ 🔍 Filter by Run ID...                 │
│ ┌────────────────────────────────────┐ │
│ │ run-12345                          │ │
│ └────────────────────────────────────┘ │
│                                        │
│ Context Filters:                       │
│ ┌─ Tenant: tenant-001                  │
│ ├─ Org: org-456                        │
│ └─ Deal: deal-789                      │
└────────────────────────────────────────┘
```

---

### Log Entry Card - Completed

```
╔════════════════════════════════════════╗
║ ┌──────────────────────────────────┐  ║
║ │ [Discovery] ✓ Completed          │  ║
║ │                                  │  ║
║ │ Fetch Fathom Meetings            │  ║
║ │                        12:34:56  │  ║
║ │                        2.3s      │  ║
║ ├──────────────────────────────────┤  ║
║ │ Found 3 meetings with relevant   │  ║
║ │ customer feedback and challenges │  ║
║ └──────────────────────────────────┘  ║
╚════════════════════════════════════════╝
```

**Elements**:
- Phase badge (outlined, small)
- Status badge (✓, green background)
- Step name (medium weight)
- Timestamp (muted, right-aligned)
- Duration (muted, right-aligned)
- Notes section (optional, smaller text)

---

### Log Entry Card - Running

```
╔════════════════════════════════════════╗
║ ┌──────────────────────────────────┐  ║
║ │ [ROI] ⟳ Running                  │  ║
║ │                                  │  ║
║ │ Calculate ROI Statistics         │  ║
║ │                        12:35:00  │  ║
║ │                        Running   │  ║
║ └──────────────────────────────────┘  ║
╚════════════════════════════════════════╝
```

**Elements**:
- Phase badge (outlined, small)
- Status badge (⟳, blue background, spinning)
- Step name (medium weight)
- Timestamp (muted, right-aligned)
- "Running" text instead of duration

---

### Log Entry Card - Error

```
╔════════════════════════════════════════╗
║ ┌──────────────────────────────────┐  ║
║ │ [Solution] ✗ Error               │  ║
║ │                                  │  ║
║ │ Generate Solution Summary        │  ║
║ │                        12:35:15  │  ║
║ │                        1.2s      │  ║
║ ├──────────────────────────────────┤  ║
║ │ API rate limit exceeded. Please  │  ║
║ │ try again in 60 seconds.         │  ║
║ └──────────────────────────────────┘  ║
╚════════════════════════════════════════╝
```

**Elements**:
- Phase badge (outlined, small)
- Status badge (✗, red background)
- Step name (medium weight)
- Timestamp (muted, right-aligned)
- Duration shown
- Error message in notes (red text)

---

### Log Entry Card - Pending

```
╔════════════════════════════════════════╗
║ ┌──────────────────────────────────┐  ║
║ │ [Export] ○ Pending               │  ║
║ │                                  │  ║
║ │ Export to Gamma                  │  ║
║ │                        -         │  ║
║ │                        -         │  ║
║ └──────────────────────────────────┘  ║
╚════════════════════════════════════════╝
```

**Elements**:
- Phase badge (outlined, small)
- Status badge (○, gray background)
- Step name (medium weight)
- No timestamp or duration (dashes)

---

## 🎨 Status Badge Colors

### Completed ✓
```
┌──────────────┐
│ ✓ Completed  │  ← Green-50 background
└──────────────┘    Green-700 text
                    Green-200 border
```

### Running ⟳
```
┌──────────────┐
│ ⟳ Running    │  ← Blue-50 background
└──────────────┘    Blue-700 text
                    Blue-200 border
                    Spinning animation
```

### Error ✗
```
┌──────────────┐
│ ✗ Error      │  ← Red-50 background
└──────────────┘    Red-700 text
                    Red-200 border
```

### Pending ○
```
┌──────────────┐
│ ○ Pending    │  ← Gray-50 background
└──────────────┘    Gray-700 text
                    Gray-200 border
```

---

## 📊 Empty State

```
┌────────────────────────────────────────┐
│                                        │
│            ⚠️                          │
│                                        │
│         No logs found                  │
│                                        │
│    Run an agent to see logs here      │
│                                        │
└────────────────────────────────────────┘
```

---

## 🔄 Loading State

```
┌────────────────────────────────────────┐
│                                        │
│            ⟳                           │
│                                        │
│         Loading logs...                │
│                                        │
└────────────────────────────────────────┘
```

---

## 📱 Footer Controls

```
┌────────────────────────────────────────┐
│ 5 log entries      [✓] Auto-refresh    │
└────────────────────────────────────────┘
    ↑                      ↑
  Count              Toggle checkbox
```

---

## 🎬 Animation States

### 1. **Auto-Refresh Indicator**
When auto-refresh is active, show subtle pulsing on refresh button:
```
[⟳] ← Pulse every 5 seconds
```

### 2. **New Log Entry**
When new log appears, fade in with slide animation:
```
╔════════════════╗
║ [New entry]    ║ ← Slide down + fade in
╚════════════════╝
```

### 3. **Status Change**
When status changes from "running" to "completed", update badge with color transition:
```
[⟳ Running] → [✓ Completed]
  (fade)        (fade)
```

---

## 🎨 Theme Support

### Light Mode
```
Background: White
Text: Dark gray
Borders: Light gray (#E5E7EB)
Cards: White with shadow
```

### Dark Mode
```
Background: Dark gray (#1F2937)
Text: Light gray
Borders: Gray (#374151)
Cards: Darker gray with subtle shadow
```

---

## 📐 Responsive Breakpoints

### Desktop (lg: 1024px+)
- Two-column layout
- Run Log: 1/3 width
- Main content: 2/3 width
- Sticky positioning enabled

### Tablet (md: 768px - 1023px)
- Single column layout
- Run Log below main content
- Full width for both sections

### Mobile (< 768px)
- Single column layout
- Simplified log cards
- Reduced padding
- Smaller text sizes

---

## ✅ Visual Checklist

- [x] Progress bar with phase indicators
- [x] Phase names with arrows
- [x] Current phase highlighted
- [x] Filter input for run ID
- [x] Context badges (tenant, org, deal)
- [x] Scrollable log area
- [x] Status badges with icons
- [x] Timestamp formatting
- [x] Duration formatting
- [x] Notes section (expandable)
- [x] Empty state message
- [x] Loading state
- [x] Auto-refresh toggle
- [x] Manual refresh button
- [x] Footer with count
- [x] Responsive layout
- [x] Dark mode support
- [x] Hover effects
- [x] Smooth animations

---

**Visual Guide Complete!** 🎨

All UI elements have been designed with consistency, accessibility, and user experience in mind.
